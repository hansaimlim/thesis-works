These files contain kinase-ligand(chemical) binding activities appearing in activities/tsv/integrated_kinases_continuous.tsv.
The chemicals are separated into two groups of 131620 training chemicals and 3135 dev/test chemicals.
The chemicals are separated in a way that the maximum structural similarity between a training chemical and a dev/test chemical is 0.6, measured by 
Tanimoto coefficient of ECFP4. In other words, dev/test chemicals represent structurally novel molecules compared to the training chemical set.

For binary activities, pIC50 >= 6.0 is considered active, and pKi or pKd >= 7.0 to be active. 

File                     |#activities
------------------------ |------------
kinase_binary_dev.tsv    | 19578
kinase_binary_test.tsv   | 4941
kinase_binary_train.tsv  | 946124
------------------------ |------------
kinase_pic50_dev.tsv     | 3256
kinase_pic50_test.tsv    | 775
kinase_pic50_train.tsv   | 252175
------------------------ |------------
kinase_pki_pkd_dev.tsv   | 16322
kinase_pki_pkd_test.tsv  | 4166
kinase_pki_pkd_train.tsv | 693949


Files with _adj suffix are distribution-adjusted activities. For instance, pki-pkd activities are unusually enriched in near 4.17 and 5.0. Therefore, these two bins are adjusted so that, for each protein, max_activity_count_at_5.0 = 1.2* (average counts in [4.9,5.0) and [5.1,5.2)). If a protein has more than max, activities are randomly dropped out from data set. Refer to adjust_activity_distribution.ipynb for details.