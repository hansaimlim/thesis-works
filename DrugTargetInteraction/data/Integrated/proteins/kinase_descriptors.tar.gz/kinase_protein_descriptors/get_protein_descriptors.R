library(protr)
library(rjson)
library(stringr)

uniprot2pssm<-fromJSON(file="uniprot2triplets.json")
uniprot_pssm<-as.data.frame(uniprot2pssm)
prots<-list()
for (uniprot in names(uniprot_pssm)){
  uniprot<-str_replace_all(uniprot,".autoinhibited","")
  uniprot<-str_replace_all(uniprot,".nonphosphorylated","")
  uniprot<-str_replace_all(uniprot,".phosphorylated","")
  uniprot<-str_replace_all(uniprot,".JH1domain.catalytic","")
  uniprot<-str_replace_all(uniprot,".JH2domain.pseudokinase","")
  matches<-str_extract_all(uniprot, "[A-Z0-9]+")[[1]]

  seq <- try(getUniProt(matches[1]))
  if (inherits(seq, "try-error"))
  { print(matches[1])
    next} #skip if uniprot sequence unavailable
  if (!protcheck(seq[[1]]))
  {next} #skip if protein contains nonstandard amino acids
  if (length(matches)>1){
    for (mut in matches[2:length(matches)]){
      to_aa<-str_extract_all(mut,"[A-Z]")[[1]][2]
      pos<-as.numeric(str_extract_all(mut,"[0-9]+")[[1]][1])
      substr(seq[[1]],pos,pos)<-to_aa
    }
  } 
  prots[uniprot]<-seq
}
descscales <- extractDescScales(
  prots[[1]],
  propmat = "AADescAll",
  pc = 5, lag = 7, silent = FALSE
)
mb <- extractMoreauBroto(prots[[1]])
df.descscales <- setNames(as.data.frame(matrix(nrow = length(prots), ncol = length(names(descscales)))),
                 c(names(descscales)))
df.protfp <- setNames(as.data.frame(matrix(nrow = length(prots), ncol = length(names(descscales)))),
                          c(names(descscales)))
df.mbroto <- setNames(as.data.frame(matrix(nrow = length(prots), ncol = length(names(mb)))),
                      c(names(mb)))
df.moran <- setNames(as.data.frame(matrix(nrow = length(prots), ncol = length(names(mb)))),
                      c(names(mb)))
df.geary <- setNames(as.data.frame(matrix(nrow = length(prots), ncol = length(names(mb)))),
                     c(names(mb)))
socn <- extractSOCN(prots[[1]])
df.socn <- setNames(as.data.frame(matrix(nrow = length(prots), ncol = length(names(socn)))),
                     c(names(socn)))
apaac <- extractAPAAC(prots[[1]])
df.apaac <- setNames(as.data.frame(matrix(nrow = length(prots), ncol = length(names(apaac)))),
                    c(names(apaac)))
qso <- extractQSO(prots[[1]])
df.qso <- setNames(as.data.frame(matrix(nrow = length(prots), ncol = length(names(qso)))),
                   c(names(qso)))
row.names(df.descscales)<-names(prots)
row.names(df.protfp)<-names(prots)
row.names(df.mbroto)<-names(prots)
row.names(df.moran)<-names(prots)
row.names(df.geary)<-names(prots)
row.names(df.socn)<-names(prots)
row.names(df.apaac)<-names(prots)
row.names(df.qso)<-names(prots)
for (i in 1:length(prots)){
  uni <- names(prots)[i]
  df.descscales[uni,] <- extractDescScales(prots[[i]],propmat="AADescAll",pc=5,lag=7,silent=TRUE)
  df.protfp[uni,] <- extractProtFP(prots[[i]],index=c(1:544),pc=5,lag=7,scale=TRUE,silent=TRUE)
  df.mbroto[uni,] <- extractMoreauBroto(prots[[i]])
  df.moran[uni,] <- extractMoran(prots[[i]])
  df.geary[uni,] <- extractGeary(prots[[i]])
  df.socn[uni,] <- extractSOCN(prots[[i]])
  df.apaac[uni,] <- extractAPAAC(prots[[i]])
  df.qso[uni,] <- extractQSO(prots[[i]])
}
write.table(x=df.descscales,file='DescScales.tsv',sep='\t',quote=FALSE)
write.table(x=df.protfp,file='ProtFP.tsv',sep='\t',quote=FALSE)
write.table(x=df.mbroto,file='MoreauBroto.tsv',sep='\t',quote=FALSE)
write.table(x=df.moran,file='Moran.tsv',sep='\t',quote=FALSE)
write.table(x=df.geary,file='Geary.tsv',sep='\t',quote=FALSE)
write.table(x=df.socn,file='SOCN.tsv',sep='\t',quote=FALSE)
write.table(x=df.apaac,file='APAAC.tsv',sep='\t',quote=FALSE)
write.table(x=df.qso,file='QSO.tsv',sep='\t',quote=FALSE)